<?php
require "model_layer/DBManager.php";

if (isset($_POST['id_usuario']) && isset($_POST['id_producto'])) {
    $id_usuario = intval($_POST['id_usuario']);
    $id_producto = intval($_POST['id_producto']);
    
    $db = new DBManager();
    $fecha_publicacion = $db->getFechaPublicacion($id_usuario, $id_producto);
    
    if ($fecha_publicacion) {
        echo json_encode(array("fecha_publicacion" => $fecha_publicacion));
    } else {
        echo json_encode(array("message" => "No se encontró la publicación para los parámetros dados"));
    }
} else {
    echo json_encode(array("message" => "Error, faltan datos requeridos"));
}
?>
