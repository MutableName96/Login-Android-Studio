<?php
require "model_layer/DBManager.php";

if (isset($_POST['id_producto']) && isset($_POST['fecha'])) {
    $id_producto = intval($_POST['id_producto']);
    $fecha = $_POST['fecha']; 

    $db = new DBManager();
    $resultado = $db->addVenta($id_producto, $fecha);

    if ($resultado) {
        echo json_encode(array("message" => "Venta registrada correctamente"));
    } else {
        echo json_encode(array("message" => "Error al registrar la venta"));
    }
} else {
    echo json_encode(array("message" => "Error, faltan datos requeridos"));
}
?>
