<?php
require "model_layer/DBManager.php";

if (isset($_POST['id_producto'])) {
    $id_producto = intval($_POST['id_producto']);
    $db = new DBManager();
    $resultado = $db->removePublicacion($id_producto);

    if ($resultado) {
        echo json_encode(array("message" => "Publicación eliminada correctamente"));
    } else {
        echo json_encode(array("message" => "Error al eliminar publicación"));
    }
} else {
    echo json_encode(array("message" => "Error, falta el ID de producto"));
}
?>
