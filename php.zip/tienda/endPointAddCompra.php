<?php
require "model_layer/DBManager.php";

if (isset($_POST['id_usuario']) && isset($_POST['id_producto']) && isset($_POST['fecha'])) {
    $id_usuario = intval($_POST['id_usuario']);
    $id_producto = intval($_POST['id_producto']);
    $fecha = $_POST['fecha']; 

    $db = new DBManager();
    $resultado = $db->addCompra($id_usuario, $id_producto, $fecha);

    if ($resultado) {
        echo json_encode(array("message" => "Compra registrada correctamente"));
    } else {
        echo json_encode(array("message" => "Error al registrar la compra"));
    }
} else {
    echo json_encode(array("message" => "Error, faltan datos requeridos"));
}
?>
