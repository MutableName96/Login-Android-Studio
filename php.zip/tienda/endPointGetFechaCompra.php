<?php
require "model_layer/DBManager.php";

if (isset($_POST['id_usuario']) && isset($_POST['id_producto'])) {
    $id_usuario = intval($_POST['id_usuario']);
    $id_producto = intval($_POST['id_producto']);

    $db = new DBManager();
    $fecha_compra = $db->getFechaCompra($id_usuario, $id_producto);

    if ($fecha_compra) {
        echo json_encode(array("fecha_compra" => $fecha_compra));
    } else {
        echo json_encode(array("message" => "No se encontró la fecha de compra para los parámetros dados."));
    }
} else {
    echo json_encode(array("message" => "Error, faltan datos requeridos."));
}
?>