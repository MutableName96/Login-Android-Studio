<?php
require "model_layer/DBManager.php";

if (isset($_POST['categoria'])) {
    $categoria = $_POST['categoria'];

    $db = new DBManager();
    $productos = $db->getListProductosPorCategoria($categoria);

    if (!empty($productos)) {
        echo json_encode($productos);
    } else {
        echo json_encode(array("message" => "No se encontraron productos para esta categoría"));
    }
} else {
    echo json_encode(array("message" => "Error, falta la categoria"));
}
?>