<?php
require "model_layer/DBManager.php";

if (isset($_POST['nombre']) && isset($_POST['telefono']) && isset($_POST['correo']) && isset($_POST['usuario']) && isset($_POST['password']) && isset($_POST['tipo_usuario'])) {
    $nombre = $_POST['nombre'];
    $telefono = $_POST['telefono'];
    $correo = $_POST['correo'];
    $usuario = $_POST['usuario'];
    $password = $_POST['password'];
    $tipo_usuario = $_POST['tipo_usuario'];

    $db = new DBManager();
    $resultado = $db->addUser($nombre, $telefono, $correo, $usuario, $password, $tipo_usuario);

    if ($resultado) {
        echo json_encode(array("message" => "Usuario agregado correctamente"));
    } else {
        echo json_encode(array("message" => "Error al agregar usuario"));
    }
} else {
    echo json_encode(array("message" => "Error, faltan datos requeridos"));
}
?>
