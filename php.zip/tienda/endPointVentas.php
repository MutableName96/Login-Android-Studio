<?php

require "model_layer/DBManager.php";

if (isset($_POST['id_usuario'])) {
    $id_usuario = intval($_POST['id_usuario']);
    $db = new DBManager();
    $resultado = $db->getVentas($id_usuario);

    echo json_encode($resultado);
} else {
    echo json_encode(["error" => "ID de usuario no proporcionado."]);
}
?>
