<?php
require "model_layer/DBManager.php";

if (isset($_POST['id_usuario']) && isset($_POST['nombre']) && isset($_POST['descripcion']) && isset($_POST['categoria']) && isset($_POST['condicion']) && isset($_POST['marca']) && isset($_POST['disponibilidad']) && isset($_POST['precio']) && isset($_POST['ganancia']) && isset($_POST['fecha'])) {
    $id_usuario = intval($_POST['id_usuario']);
    $nombre = $_POST['nombre'];
    $descripcion = $_POST['descripcion'];
    $categoria = $_POST['categoria'];
    $condicion = $_POST['condicion'];
    $marca = $_POST['marca'];
    $disponibilidad = $_POST['disponibilidad'] === 'true' ? 1 : 0;
    $precio = floatval($_POST['precio']);
    $ganancia = floatval($_POST['ganancia']);
    $fecha = $_POST['fecha'];

    $db = new DBManager();
    $resultado = $db->addProducto($id_usuario, $nombre, $descripcion, $categoria, $condicion, $marca, $disponibilidad, $precio, $ganancia, $fecha);

    if ($resultado) {
        echo json_encode(array("message" => "Producto agregado correctamente"));
    } else {
        echo json_encode(array("message" => "Error al agregar producto"));
    }
} else {
    echo json_encode(array("message" => "Error, faltan datos requeridos"));
}
?>
