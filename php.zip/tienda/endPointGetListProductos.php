<?php

require "model_layer/DBManager.php";

$db = new DBManager();
$resultado = $db->getListProductos();

echo json_encode($resultado);

?>
