<?php

require "model_layer/DBManager.php";

if (isset($_POST['telefono']) && isset($_POST['password'])) {
    $db = new DBManager();
    $resultado = $db->findUser($_POST['telefono'], $_POST['password']);
    echo json_encode($resultado);
} else {
    die('Error, se requiere el teléfono y password');
}

?>
