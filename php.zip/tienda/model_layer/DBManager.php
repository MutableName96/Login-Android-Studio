<?php

class DBManager
{
    private $db;
    private $host;
    private $user;
    private $pass;
    private $port;

    public function __construct()
    {
        $this->db = "tienda";
        $this->host = "localhost";
        $this->user = "root";
        $this->pass = null;
        $this->port = 3306;
    }

    private function open()
    {
        $link = mysqli_connect(
            $this->host,
            $this->user,
            $this->pass,
            $this->db,
            $this->port
        ) or die('Error al abrir conexion');

        return $link;
    }

    private function close($link)
    {
        mysqli_close($link);
    }

    public function findUser($telefono, $password)
    {
        $link = $this->open();

        $sql = "SELECT * FROM usuarios WHERE telefono=? AND password=SHA1(?)";
        $stmt = $link->prepare($sql);
        $stmt->bind_param("ss", $telefono, $password);

        $stmt->execute();
        $result = $stmt->get_result();

        $rows = [];
        while ($row = $result->fetch_assoc()) {
            $rows[] = $row;
        }

        $stmt->close();
        $this->close($link);

        return $rows;
    }

    public function addUser($nombre, $telefono, $correo, $usuario, $password, $tipo_usuario)
    {
        $link = $this->open();

        $sql = "INSERT INTO usuarios (nombre, telefono, correo, user, password, tipo_usuario) VALUES (?, ?, ?, ?, SHA1(?), ?)";

        $query = mysqli_prepare($link, $sql);
        mysqli_stmt_bind_param($query, "ssssss", $nombre, $telefono, $correo, $usuario, $password, $tipo_usuario);

        $resultado = mysqli_stmt_execute($query);

        if (!$resultado) {
            error_log("Error en la consulta: " . mysqli_stmt_error($query));
        }

        $this->close($link);

        return $resultado;
    }

    public function getListProductos()
    {
        $link = $this->open();
        $sql = "SELECT * FROM productos WHERE disponibilidad=1";
        $result = mysqli_query($link, $sql);

        $rows = [];
        while ($row = mysqli_fetch_assoc($result)) {
            // Convertir los tipos de datos
            $row['disponibilidad'] = (bool)$row['disponibilidad'];
            $row['precio'] = (float)$row['precio'];
            $row['ganancia'] = (float)$row['ganancia'];

            $rows[] = $row;
        }

        $this->close($link);

        return $rows;
    }

    public function getPublicaciones($id_usuario)
    {
        $link = $this->open();

        $sql = "SELECT * FROM productos WHERE id_producto IN (SELECT id_producto FROM usuarios_publicaciones WHERE id_usuario = ?)";
        $stmt = mysqli_prepare($link, $sql);
        mysqli_stmt_bind_param($stmt, 'i', $id_usuario);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        $rows = [];
        while ($row = mysqli_fetch_assoc($result)) {
            $row['disponibilidad'] = (bool)$row['disponibilidad'];
            $row['precio'] = (float)$row['precio'];
            $row['ganancia'] = (float)$row['ganancia'];
            $rows[] = $row;
        }

        $this->close($link);

        return $rows;
    }

    public function getCompras($id_usuario)
    {
        $link = $this->open();

        $sql = "SELECT * FROM productos WHERE id_producto IN (
        SELECT id_producto FROM usuarios_compras WHERE id_usuario = ?
    )";

        $query = mysqli_prepare($link, $sql);
        mysqli_stmt_bind_param($query, "i", $id_usuario);

        mysqli_stmt_execute($query);
        $result = mysqli_stmt_get_result($query);

        $rows = [];
        while ($columns = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
            $columns['disponibilidad'] = ($columns['disponibilidad'] === "1") ? true : false;
            $rows[] = $columns;
        }

        $this->close($link);

        return $rows;
    }

    public function getVentas($id_usuario)
    {
        $link = $this->open();

        if ($id_usuario < 0) {
            $sql = "SELECT * FROM productos";
            $query = mysqli_prepare($link, $sql);
        } else {
            $sql = "SELECT * FROM productos WHERE id_producto IN (
            SELECT id_producto FROM usuarios_ventas WHERE id_usuario = ?
        )";
            $query = mysqli_prepare($link, $sql);
            mysqli_stmt_bind_param($query, "i", $id_usuario);
        }

        mysqli_stmt_execute($query);
        $result = mysqli_stmt_get_result($query);

        $rows = [];
        while ($columns = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
            $columns['disponibilidad'] = ($columns['disponibilidad'] === "1") ? true : false;
            $rows[] = $columns;
        }

        $this->close($link);

        return $rows;
    }

    public function addProducto($id_usuario, $nombre, $descripcion, $categoria, $condicion, $marca, $disponibilidad, $precio, $ganancia, $fecha)
    {
        $link = $this->open();
        $resultados = 0;

        $sql = "INSERT INTO productos (nombre, descripcion, categoria, condicion, marca, disponibilidad, precio, ganancia) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        $query = mysqli_prepare($link, $sql);
        mysqli_stmt_bind_param($query, "ssssssdd", $nombre, $descripcion, $categoria, $condicion, $marca, $disponibilidad, $precio, $ganancia);

        $resultado = mysqli_stmt_execute($query);

        if ($resultado) {
            $id_producto = mysqli_insert_id($link);
            $sql = "INSERT INTO usuarios_publicaciones (id_usuario, id_producto, fecha_publicacion) VALUES (?, ?, ?)";
            $query = mysqli_prepare($link, $sql);
            mysqli_stmt_bind_param($query, "iis", $id_usuario, $id_producto, $fecha);
            $resultados = mysqli_stmt_execute($query);
        }

        if (!$resultado) {
            error_log("Error en la consulta: " . mysqli_stmt_error($query));
        }

        $this->close($link);

        return $resultados;
    }

    public function removePublicacion($id_producto)
    {
        $link = $this->open();
        $resultados = 0;

        $sql = "UPDATE productos SET disponibilidad = false WHERE id_producto = ?";
        $query = mysqli_prepare($link, $sql);
        mysqli_stmt_bind_param($query, "i", $id_producto);

        $resultados = mysqli_stmt_execute($query);

        if (!$resultados) {
            error_log("Error en la consulta: " . mysqli_stmt_error($query));
        }

        $this->close($link);

        return $resultados;
    }


    public function addCompra($id_usuario, $id_producto, $fecha)
    {
        $link = $this->open();
        $resultados = 0;

        $sql = "INSERT INTO usuarios_compras (id_usuario, id_producto, fecha_compra) VALUES (?, ?, ?)";
        $query = mysqli_prepare($link, $sql);
        mysqli_stmt_bind_param($query, "iis", $id_usuario, $id_producto, $fecha);

        $resultados = mysqli_stmt_execute($query);

        if (!$resultados) {
            error_log("Error en la consulta: " . mysqli_stmt_error($query));
        }

        $this->close($link);

        return $resultados;
    }

    public function addVenta($id_producto, $fecha)
    {
        $link = $this->open();
        $resultados = 0;

        $sql = "INSERT INTO usuarios_ventas (id_usuario, id_producto, fecha_venta) VALUES ((SELECT id_usuario FROM usuarios_publicaciones WHERE id_producto = ?), ?, ?)";
        $query = mysqli_prepare($link, $sql);
        mysqli_stmt_bind_param($query, "iss", $id_producto, $id_producto, $fecha);

        $resultados = mysqli_stmt_execute($query);

        if (!$resultados) {
            error_log("Error en la consulta: " . mysqli_stmt_error($query));
        }

        $this->close($link);

        return $resultados;
    }

    public function getFechaVenta($id_usuario, $id_producto)
    {
        $link = $this->open();
        $fecha = null;

        $sql = "SELECT fecha_venta FROM usuarios_ventas WHERE id_usuario = ? AND id_producto = ?";
        $query = mysqli_prepare($link, $sql);
        mysqli_stmt_bind_param($query, "ii", $id_usuario, $id_producto);

        mysqli_stmt_execute($query);
        $result = mysqli_stmt_get_result($query);

        if ($row = mysqli_fetch_assoc($result)) {
            $fecha = $row['fecha_venta'];
        }

        $this->close($link);

        return $fecha;
    }

    public function getFechaCompra($id_usuario, $id_producto)
    {
        $link = $this->open();

        $sql = "SELECT fecha_compra FROM usuarios_compras WHERE id_usuario = ? AND id_producto = ?";
        $query = mysqli_prepare($link, $sql);
        mysqli_stmt_bind_param($query, "ii", $id_usuario, $id_producto);

        mysqli_stmt_execute($query);
        $result = mysqli_stmt_get_result($query);

        $fecha_compra = null;
        if ($row = mysqli_fetch_assoc($result)) {
            $fecha_compra = $row['fecha_compra'];
        }

        $this->close($link);

        return $fecha_compra;
    }

    public function getFechaPublicacion($id_usuario, $id_producto)
    {
        $link = $this->open();

        $sql = "SELECT fecha_publicacion FROM usuarios_publicaciones WHERE id_usuario = ? AND id_producto = ?";
        $query = mysqli_prepare($link, $sql);
        mysqli_stmt_bind_param($query, "ii", $id_usuario, $id_producto);

        mysqli_stmt_execute($query);
        $result = mysqli_stmt_get_result($query);

        $fecha = null;
        if ($row = mysqli_fetch_assoc($result)) {
            $fecha = $row['fecha_publicacion'];
        }

        $this->close($link);

        return $fecha;
    }

    public function getListProductosPorCategoria($categoria)
    {
        $link = $this->open();

        $sql = "SELECT * FROM productos WHERE categoria = ? AND disponibilidad = 1";
        $stmt = mysqli_prepare($link, $sql);
        mysqli_stmt_bind_param($stmt, 's', $categoria);

        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        $rows = [];
        while ($row = mysqli_fetch_assoc($result)) {
            // Convertir los tipos de datos
            $row['disponibilidad'] = (bool)$row['disponibilidad'];
            $row['precio'] = (float)$row['precio'];
            $row['ganancia'] = (float)$row['ganancia'];

            $rows[] = $row;
        }

        mysqli_stmt_close($stmt);
        $this->close($link);

        return $rows;
    }
}
